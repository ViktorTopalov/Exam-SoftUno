from django.shortcuts import render, redirect

from final_exam_project.book.forms import BookForm
from final_exam_project.book.models import Book


# Create your views here.
